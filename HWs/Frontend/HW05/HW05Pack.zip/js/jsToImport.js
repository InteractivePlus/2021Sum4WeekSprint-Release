class HiddenFlagInfo{
    getFlagInfo(){
        return 'ANINWINIMIMIJIWJUUSUIAMIOJIWOJIOJIJUHUWHUDJWUJDIJIJAIJUWUFHUHWUDHUW';
    }
}

export default HiddenFlagInfo;