import {validateFlag} from './q01validate.js';

/**
 * Write your import statement below
 * 在下方编写你的导入(import)语句
 */

/**
 * Write your import statement above
 * 在上方写入你的导入(import)语句
 */

function q01Func(){
    let extractedFlag = undefined;

    /**
     * Write your code below
     * 在下方编写你的代码
     */

    //TODO: Import HiddenFlagInfo Class(from jsToImport.js) and initiate a new HiddenFlagInfo object, and read the hiddenFlag by calling object.getFlagInfo()
    extractedFlag = 'FLAG GOES HERE';

    /**
     * Write your code above
     * 在上方编写你的代码
     */

    validateFlag(extractedFlag);
}

export {q01Func};